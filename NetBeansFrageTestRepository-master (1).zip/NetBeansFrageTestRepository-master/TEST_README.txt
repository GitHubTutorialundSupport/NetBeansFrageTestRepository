Hallo zusammen
diese Txt Datei soll jetzt testweise geforked werden! lolololol