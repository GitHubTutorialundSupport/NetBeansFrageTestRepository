# ILP2017
Studienarbeit Informationslogistische Prozesse 2017
